-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2021 at 11:15 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Id` int(4) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Date of Birth` varchar(20) NOT NULL,
  `Designation` varchar(100) NOT NULL,
  `Salary` int(40) NOT NULL,
  `Hired Date` varchar(50) NOT NULL,
  `Contact Number` int(30) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Id`, `Name`, `Gender`, `Date of Birth`, `Designation`, `Salary`, `Hired Date`, `Contact Number`, `Address`, `Email`) VALUES
(1, 'mehedi', 'Male', '1-01-1997', 'Gateman', 60000, '17-05-2020', 1303074910, 'khilkhet,dhaka-1206', 'mehedi7728@gmail.com'),
(2, 'faisal', 'male', '12-05-1997', 'gateman', 50000, '17-09-2019', 1701037691, 'nikunjo,dhaka 1206', 'faisaldka0@gmail.com'),
(3, 'omi', 'feMale', '15-04-1999', 'nurse', 20000, '10-08-2020', 1779687356, 'khilkhet,dhaka 1238', 'omiomi12@gmail.com'),
(4, 'jannat', 'Female', '12-05-1999', 'servent', 20000, '25-09-2017', 1515602057, 'monipur,dhaka 1206', 'woman85@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
